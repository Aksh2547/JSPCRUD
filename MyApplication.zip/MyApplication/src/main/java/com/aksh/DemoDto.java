package com.aksh;

public class DemoDto {
	
	String toDate;
	String fromDate;
	String messageId;
	
	public DemoDto(String toDate, String fromDate, String messageId) {
		super();
		this.toDate = toDate;
		this.fromDate = fromDate;
		this.messageId = messageId;
	}
	
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getMessageId() {
		return messageId;
	}
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	
	

}
