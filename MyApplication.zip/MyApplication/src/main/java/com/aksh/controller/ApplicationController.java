package com.aksh.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.aksh.DTO.ResultData;
import com.aksh.Service.DataService;

@Controller
public class ApplicationController {

    @Autowired
    private DataService dataService;

    @GetMapping("/")
    public String showForm(Model model) {
        List<String> amcCodes = dataService.getAmcCodes();
        System.out.println("AMC Codes 1: " + amcCodes);
        model.addAttribute("amcCodes", amcCodes);
        return "test";
    }

    @PostMapping("/fetchData")
    public String fetchData(
            @RequestParam("fromDate") String fromDate,
            @RequestParam("toDate") String toDate,
            @RequestParam("amcCode") String amcCode,
            @RequestParam("status") String status,
            Model model) {
        ResultData resultData = dataService.fetchData(fromDate, toDate, amcCode, status);
        model.addAttribute("amcCodes", dataService.getAmcCodes());
        model.addAttribute("resultData", resultData != null ? resultData : null);
        return "test";
    }
}
