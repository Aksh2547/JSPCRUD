package com.aksh.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ApplicationController {

//	@GetMapping("/home")
//	public String Hello() {
//		return "welcomepage";
//	}

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public String Welcome() {
		return "wel";
	}
	
	@RequestMapping(value = "/view", method = RequestMethod.POST)
	public String view() {
		return "wel";
	}

}
