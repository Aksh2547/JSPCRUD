package com.aksh.Reository;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.aksh.DTO.ResultData;

@Repository
public class AmcRepository {

    public List<String> fetchAmcCodes() {
        // Mock data; replace with a database call
        return Arrays.asList("AMC001", "AMC002", "AMC003", "AMC004");
    }

    public ResultData fetchResultData(String fromDate, String toDate, String amcCode, String status) {
        // Mock logic; replace with a database call
        if ("AMC001".equals(amcCode) && "Active".equalsIgnoreCase(status)) {
            return new ResultData("Sample result for AMC001 with status Active.");
        }
        return null;
    }
}
