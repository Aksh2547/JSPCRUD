package com.aksh.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aksh.DTO.ResultData;
import com.aksh.Reository.AmcRepository;

import java.util.List;

@Service
public class DataService {

    @Autowired
    private AmcRepository amcRepository;

    public List<String> getAmcCodes() {
        // Fetch AMC codes from database
        return amcRepository.fetchAmcCodes();
    }

    public ResultData fetchData(String fromDate, String toDate, String amcCode, String status) {
        // Fetch data logic based on the criteria
        return amcRepository.fetchResultData(fromDate, toDate, amcCode, status);
    }
}
